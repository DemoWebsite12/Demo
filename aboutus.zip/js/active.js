(function ($) {
"use strict";

/*--------------------------------------
	Counter Up Active
----------------------------------------*/
$('.counter').counterUp({
	delay:10,
	time:2000,
});


})(jQuery);	
